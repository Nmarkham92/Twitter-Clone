///////////////////////////
// Javascript for Post page
//////////////////////////

$(function() {
    $('.js-menu-icon').click(function() {
        $(this).next().toggle();
    })
})